# rollinggo-mcp

`rollinggo-mcp` is a FastMCP-based RollingGo hotel server for MCP clients that connect over `stdio`.

This package is separate from the existing CLI projects in `rollinggo-npx` and `rollinggo-uv`. It exposes hotel tools directly as MCP tools:

- `searchHotels`
- `getHotelDetail`
- `getHotelSearchTags`

## Package And Command

- package name: `rollinggo-mcp`
- command name: `rollinggo-mcp`

## Environment

The server resolves configuration in this order:

1. `ROLLINGGO_API_KEY`
2. `AIGOHOTEL_API_KEY`

Optional overrides:

- `ROLLINGGO_BASE_URL`

Example:

```bash
$env:ROLLINGGO_API_KEY="mcp_your_key"
node dist/index.js
```

## Local Development

Install dependencies:

```bash
npm install
```

Build:

```bash
npm run build
```

Run tests:

```bash
npm test
```

Run the stdio server from source output:

```bash
node dist/index.js
```

## MCP Client Config

Published package form:

```json
{
  "mcpServers": {
    "rollinggo-hotel": {
      "command": "npx",
      "args": ["-y", "rollinggo-mcp"],
      "env": {
        "ROLLINGGO_API_KEY": "mcp_your_key"
      }
    }
  }
}
```

Local repository form:

```json
{
  "mcpServers": {
    "rollinggo-hotel": {
      "command": "node",
      "args": ["d:/work/RollingGo-Overseas/rollinggo-hotel-npm/dist/index.js"],
      "env": {
        "ROLLINGGO_API_KEY": "mcp_your_key"
      }
    }
  }
}
```

## Notes

- transport defaults to `stdio`
- the server removes `bookingUrl` fields before returning results
- FastMCP version is pinned to `3.34.0`
